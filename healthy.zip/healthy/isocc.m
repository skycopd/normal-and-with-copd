%Title: COPD Project for ISOCC
%Project Series of Sleep Apnea
%Author: Engr. Evelyn Q. Raguindin
%Date: July 8, 2022

%Clearing po variables
clc
clear all
close all


%data importing from excel file

data1=readtable('dataset2.xlsx','Range','D1:D471'); %display Column of Time
data2=readtable('dataset2.xlsx','Range','E1:E471'); %display Column of SpO2
data3=readtable('dataset2.xlsx','Range','F1:F471'); %display Column of Respirtory Rate

%display tabulated format
%just removed the semicolon ";" if you want to view the data in MATLAB

dataA=[data1]; %column selection from Date, timestamp, LM, LW, HR, and SpO2

dataB=[data2 data3]; %column selection from LM, LW, HR, and SpO2

figure
stackedplot(dataB); %display the graphplot of LM, LW, HR, and SpO2
xlabel('Time Stamp (second)');

set(gca, 'fontname', 'Times');
set(gca, 'FontSize', 15);

xlim([0 360]);

title('Healthy');






